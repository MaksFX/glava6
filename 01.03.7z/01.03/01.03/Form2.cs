﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _01._03
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();

            string[] spisok = { "Я", "Люблю", "Системное", "Программирование" };
            listBox1.Items.AddRange(spisok);
            listBox1.Items.Add("One");
            listBox1.Items.Add("Two");
            listBox1.Items.Add("Three");
            lstColor.Items.Add(Color.Red.Name);
            lstColor.Items.Add(Color.Yellow.Name);
            lstColor.Items.Add(Color.Green.Name);
            lstColor.Items.Add(Color.Blue.Name);
            comboBox1.Items.Add("UWU");
            comboBox1.Items.Add("OWO");
            comboBox1.Items.Add("SUS");
            comboBox1.Items.Add("eorweioriweoiropewpoirioewpr");
            //6.15
            ComboBox cboNotDrop = new ComboBox();
            cboNotDrop.Parent = this;
            cboNotDrop.Width = 140;
            cboNotDrop.Height = 60;
            cboNotDrop.Items.Add("Листинг 6.15");
            cboNotDrop.Items.Add("One");
            cboNotDrop.Items.Add("Two");
            // ... и так далее 
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Graphics g = listBox1.CreateGraphics();
            float maxWidth = 0f;
            float height = 0f;
            for (int i = 0; i < listBox1.Items.Count; ++i)
            {
                float w = g.MeasureString(listBox1.Items[i].ToString(),
                listBox1.Font).Width;
                if (w > maxWidth)
                    maxWidth = w;
                height += listBox1.GetItemHeight(i);
            }
            g.Dispose();
            listBox1.Width = (int)(maxWidth + 8 + ((height > listBox1.Height - 4) ?
             16 : 0)); // 16 - ширина прокрутки 

        }
        private void lstColor_DrawItem(object sender, DrawItemEventArgs e)
        {
            if ((e.State & DrawItemState.Selected) != 0)
                e.Graphics.FillRectangle(SystemBrushes.Highlight, e.Bounds);
            else
                e.Graphics.FillRectangle(Brushes.White, e.Bounds);
            string itemText = lstColor.Items[e.Index].ToString();
            Color color = Color.FromName(itemText);
            //Рисуем строку
            e.Graphics.DrawString(itemText, Font, new SolidBrush(color),
            e.Bounds);
            Pen pen = new Pen(color);

            //Рисуем линию под строкой
            e.Graphics.DrawLine(pen, e.Bounds.X, e.Bounds.Bottom - 1,
            e.Bounds.Right, e.Bounds.Bottom - 1);
        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            Graphics g = comboBox1.CreateGraphics();
            float maxWidth = 0f;
            foreach (object o in comboBox1.Items)
            {
                float w = g.MeasureString(o.ToString(), comboBox1.Font).Width;
                if (w > maxWidth)
                    maxWidth = w;
            }
            g.Dispose();
            // 28 - учитываем ширину кнопки в поле со списком
            comboBox1.Width = (int)maxWidth + 28;
        }
        protected override void WndProc(ref System.Windows.Forms.Message m)
        {
            // константы для левой кнопки мыши
            const int WM_LBUTTONDOWN = 0x201;
            const int WM_LBUTTONDBLCLK = 0x203;
            if (m.Msg == WM_LBUTTONDOWN || m.Msg == WM_LBUTTONDBLCLK)
                return;
            base.WndProc(ref m);
        }
        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void mycomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            comboBox1.Font = new Font("Arial", 16);
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13 || e.KeyChar == 'Б')
                e.Handled = true;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Form2 = new Form3();
            Form2.Show();
        }
    }
}
