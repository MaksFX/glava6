﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _01._03
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            TextBoxEx txtNotPaste = new TextBoxEx();
            txtNotPaste.Parent = this;
            txtNotPaste.Multiline = true;
            txtNotPaste.Height = 20;
            txtNotPaste.Left = 115;
            txtNotPaste.Top = 15;
            txtNotPaste.Text = "6.22";
            // ... и так далее
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar))
                e.Handled = true;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            // по шаблону разрешаем вводить в поле цифры, знаки плюс, минус и запятую
            string pattern = "0123456789+-,";
            if (!Char.IsControl(e.KeyChar))
                if (pattern.IndexOf(e.KeyChar.ToString()) < 0)
                    e.Handled = true;

        }
        class TextBoxEx : TextBox
        {
            const int WM_PASTE = 0x0302;
 protected override void WndProc(ref Message m)
            {
                //Запрещаем обрабатывать WM_PASTE
                if (m.Msg == WM_PASTE)
                    return;
                base.WndProc(ref m);
            }
        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            string[] strWeekDay = { "Понедельник", "Вторник", "Среда" };
            textBox3.Multiline = true;
            textBox3.Lines = strWeekDay;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            // Используем escape-последовательности для переноса текста
            // на новую строку
            textBox4.Text = "Раз\r\nДва\r\nТри";
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            // Используем свойство NewLine для переноса строк
            textBox5.Text = "Месяцы года:" + Environment.NewLine + "Декабрь" +
             Environment.NewLine + "Январь...";
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            // Все вводимые символы переводятся в верхний регистр
            this.textBox6.CharacterCasing =
             System.Windows.Forms.CharacterCasing.Upper;
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (e.KeyChar == (char)13)
                e.Handled = true;
            else
                base.OnKeyPress(e);
        }

        private void textBox8_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
                e.Handled = true;
            else
                base.OnKeyPress(e);
        }

        private void textBox9_Enter(object sender, EventArgs e)
        {
            textBox9.SelectionStart = 0;
            textBox9.SelectionLength = textBox1.Text.Length;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Form3 = new Form4();
            Form3.Show();
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
