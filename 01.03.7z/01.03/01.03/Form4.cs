﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace _01._03
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();

            RichTextBoxEx rboxex = new RichTextBoxEx();
            rboxex.Parent = this;
            rboxex.Top = 100;
            rboxex.Left = 115;
            rboxex.Text = "6.35";

            richTextBox1.AllowDrop = true;
            this.richTextBox1.DragEnter +=
            new System.Windows.Forms.DragEventHandler(
            this.richTextBox1_DragEnter);
            this.richTextBox1.DragDrop +=
            new System.Windows.Forms.DragEventHandler(
            this.richTextBox1_DragEnter);
        }

        class RichTextBoxEx : RichTextBox
        {
            protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
            {
                //Проверяем на нажатие Shift+Insert и Ctrl+V
                if ((keyData & (Keys.Shift | Keys.Insert)) ==
                (Keys.Shift | Keys.Insert)
                || ((keyData & (Keys.Control | Keys.V)) ==
                (Keys.Control | Keys.V)))

                    return true;
                return base.ProcessCmdKey(ref msg, keyData);
            }
        }
        //
        private void richTextBox1_DragEnter(object sender,
 System.Windows.Forms.DragEventArgs e)
        {
            if (((DragEventArgs)e).Data.GetDataPresent(DataFormats.Text))
                ((DragEventArgs)e).Effect = DragDropEffects.Move;
            else
                ((DragEventArgs)e).Effect = DragDropEffects.None;
        }
        private void richTextBox1_DragDrop(object sender, DragEventArgs e)
        {
            richTextBox2.LoadFile((String)e.Data.GetData("Text"),
            System.Windows.Forms.RichTextBoxStreamType.RichText);
        }
        //
        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = richTextBox2.Rtf;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Устанавливаем фокус на richTextBox
            richTextBox2.Focus();
            // Устанавливаем цвет для выделенного текста
            richTextBox2.SelectionColor = Color.Red;
            // Устанавливаем шрифт
            richTextBox2.SelectionFont = new Font("Courier", 10, FontStyle.Bold);
        }

        private void richTextBox2_LinkClicked(object sender, LinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(e.LinkText);
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dateTimePicker1.CustomFormat = " ";
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            // Устанавливаем фокус
            dateTimePicker2.Focus();
            // Посылаем команду
            SendKeys.Send("{F4}");
        }

        private void label1_Click(object sender, EventArgs e)
        {
            label3.BackColor = Color.FromArgb(60, 255, 192, 192);
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            label3.BackColor = Color.FromArgb(160, 255, 192, 192);
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            linkLabel1.Text = "На нашем сайте вы найдете дополнительную информацию";
            linkLabel1.LinkArea = new LinkArea(3, 11);
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://rusproject.narod.ru/");
        }

        private void richTextBox3_TextChanged(object sender, EventArgs e)
        {

        }
        [DllImport("User32.dll")]
        static extern int GetWindowLong(IntPtr hWnd, int nIndex);
        const int GWL_STYLE = -16;
        const int WS_HSCROLL = 0x00100000;
        const int WS_VSCROLL = 0x00200000;
        // Проверка на наличие вертикальной прокрутки
        bool IsVertScrollPresent(Control control)
        {
            int style = GetWindowLong(control.Handle, GWL_STYLE);
            return (style & WS_VSCROLL) > 0;
        }
        // Проверка на наличие горизонтальной прокрутки
        bool IsHorScrollPresent(Control control)
{
 int style = GetWindowLong(control.Handle, GWL_STYLE);
 return (style & WS_HSCROLL) > 0;
}
    private void butScrollExist_Click(object sender, EventArgs e)
    {
        textBox1.Text = "Вертикальная прокрутка: " +
        IsVertScrollPresent(richTextBox1).ToString() +
        Environment.NewLine + "Горизонтальная прокрутка: " +
        IsHorScrollPresent(richTextBox1).ToString();
    }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Form4 = new Form5();
            Form4.Show();
        }
    }
}