﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _01._03
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();

        }
        // Массив, содержащий серию значков для создания анимации
        private Icon[] aIcons = new Icon[8];
        // текущий значок
        int curIcon = 0;
        private void Form5_Load(object sender, EventArgs e)
        {

            lnkSearchUrl.Text = "Yandex Google Rambler GoGo";
            lnkSearchUrl.LinkBehavior = LinkBehavior.HoverUnderline;
            lnkSearchUrl.Links.Add(0, 6, "www.yandex.ru");
            lnkSearchUrl.Links.Add(7, 6, "www.google.ru");
            lnkSearchUrl.Links.Add(14, 7, "www.rambler.ru");
            lnkSearchUrl.Links.Add(22, 4, "www.gogo.ru");
            lnkSearchUrl.LinkClicked +=
            new LinkLabelLinkClickedEventHandler(lnkCommon_LinkClicked);
            //
            aIcons[0] = new Icon("1.ico");
            aIcons[1] = new Icon("2.ico");
            aIcons[2] = new Icon("3.ico");
            aIcons[3] = new Icon("4.ico");
            aIcons[4] = new Icon("5.ico");
            aIcons[5] = new Icon("6.ico");
            aIcons[6] = new Icon("1.ico");
            aIcons[7] = new Icon("2.ico");
        }
        private void lnkCommon_LinkClicked(object sender,
    LinkLabelLinkClickedEventArgs e)
        {
            LinkLabel lnk = new LinkLabel();
            lnk = (LinkLabel)sender;
            lnk.Links[lnk.Links.IndexOf(e.Link)].Visited = true;
            System.Diagnostics.Process.Start(e.Link.LinkData.ToString());
        }

        private void Form5_Resize(object sender, EventArgs e)
        {
            if (FormWindowState.Minimized == WindowState)
                Hide();
            //6.42
        }

        private void Form5_DoubleClick(object sender, EventArgs e)
        {
            Show();
            WindowState = FormWindowState.Normal;
            //6.43
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (notifyIcon1.Visible)
                notifyIcon1.Visible = false;
            else
                notifyIcon1.Visible = true;
            //
            notifyIcon1.Icon = aIcons[curIcon];
            curIcon++;
            if (curIcon > 7) curIcon = 0;
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.timer1.Stop();
            notifyIcon1.Visible = true;
            MessageBox.Show("Мигание приостановлено");

        }
        private bool m_CloseOK = false;
        private void Form5_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Пользователь выходит из программы не через контекстное меню
            if (m_CloseOK == false)
            {
                e.Cancel = true;
                this.Hide();
            }
            // выходим из программы по-настоящему
            m_CloseOK = true;
            this.Close();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.listView1.SelectedItems.Clear();
            //Листинг 6.47. Снятие выделения с элемента 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Убираем выделение с нужного элемента
            this.listView1.SelectedItems.Clear();
            //Листинг 6.47. Снятие выделения с элемента 
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Установим фокус
            listView1.Focus();
            // Выбираем второй элемент
            listView1.Items[1].Selected = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listView1.Items.Add("sadsadaasddsa");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Form5 = new Form6();
            Form5.Show();
        }
    }
}
