﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;


namespace _01._03
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            //6.50

            // Вставьте следующий код в обработчик события Load формы
            // Используется для создания заголовков
            ColumnHeader columnheader;
            // Используется для создания элементов в ListView
            ListViewItem listviewitem;
            // Устанавливаем нужный вид
            listView1.View = View.Details;
            // Создаем несколько элементов, содержащих имена и фамилии
            listviewitem = new ListViewItem("Александр");
            listviewitem.SubItems.Add("Суворов");
            this.listView1.Items.Add(listviewitem);
            listviewitem = new ListViewItem("Наполеон");
            listviewitem.SubItems.Add("Бонапарт");
            this.listView1.Items.Add(listviewitem);
            listviewitem = new ListViewItem("Михаил");
            listviewitem.SubItems.Add("Кутузов");
            this.listView1.Items.Add(listviewitem);
            listviewitem = new ListViewItem("Юлий");
            listviewitem.SubItems.Add("Цезарь");
            this.listView1.Items.Add(listviewitem);
            // Создаем колонки
            columnheader = new ColumnHeader();
            columnheader.Text = "Имя";
            this.listView1.Columns.Add(columnheader);
            columnheader = new ColumnHeader();
            columnheader.Text = "Фамилия";
            this.listView1.Columns.Add(columnheader);

 // Проходим через все элементы и устанавливаем размер каждого
 // заголовка колонки равным тексту
            foreach (ColumnHeader ch in this.listView1.Columns) { ch.Width = -2; }
        }

        private void listView1_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            //6.51

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        /// <summary> 6.52
        /// Этот класс реализует интерфейс IComparer.
        /// </summary>
        public class ListViewColumnSorter : IComparer
        {
            /// <summary>
            /// Номер колонки, по которой проводится сортировка
            /// </summary>
            private int ColumnToSort;
            /// <summary>
            /// Порядок, в котором проводится сортировка (например 'Ascending')
            /// </summary>
            private SortOrder OrderOfSort;
            /// <summary>
            /// Объект, проводящий нечувствительную к регистру сортировку
            /// </summary>
            private CaseInsensitiveComparer ObjectCompare;
            /// <summary>
            /// Конструктор. Инициализирует различные элементы
            /// </summary>
            public ListViewColumnSorter()
            {
                // Инициализировать колонку значением 0
                ColumnToSort = 0;
                // Иниацилизировать порядок сортировки значением 'none'
                OrderOfSort = SortOrder.None;
                // Инициализировать объект CaseInsensitiveComparer
                ObjectCompare = new CaseInsensitiveComparer();
            }
            /// <summary>
            /// Этот метод унаследован от интерфейса IComparer. Он сравнивает
            /// два переданных ему объекта, не обращая внимания на регистр
            /// </summary>
            /// <param name="x">Первый объект для сравнения</param>
            /// <param name="y">Второй объект для сравнения</param>
            /// <returns>Результат сравнения. '0' в случае равенства,
            /// отрицательный если 'x' меньше 'y' и положительный
            /// если 'x' больше 'y'</returns>
            public int Compare(object x, object y)
            {
                int compareResult;
                ListViewItem listviewX, listviewY;
            // Преобразует объекты для сравнения в объекты ListViewItem
 listviewX = (ListViewItem)x;
                listviewY = (ListViewItem)y;
                // Сравнивает 2 значения
                compareResult = ObjectCompare.Compare(
                listviewX.SubItems[ColumnToSort].Text,
                listviewY.SubItems[ColumnToSort].Text);
                // Подсчитывает возвращаемый результат, базируясь на результате
                // сравнения
                if (OrderOfSort == SortOrder.Ascending)
                {
                    // Выбрана сортировка по возрастанию, возвращаем результат
                    // операции сравнения
                    return compareResult;
                }
                else if (OrderOfSort == SortOrder.Descending)
                {
                    // Выбрана сортировка по убыванию, возвращаем результат
                    // операции сравнения со знаком минус
                    return (-compareResult);
                }
                else
                {
                    // Возвращаем 0, чтобы показать равенство
                    return 0;
                }
            }
            /// <summary>
            /// Получает или возвращает номер колонки, к которой применять
            /// сортировку (по умолчанию 0).
            /// </summary>
            public int SortColumn
            {
                set
                {
                    ColumnToSort = value;
                }
                get
                {
                    return ColumnToSort;
                }
            }
 /// <summary>
 /// Устанавливает порядок сортировки (например, 'Ascending').
 /// </summary>
            public SortOrder Order
            {
                set
                {
                    OrderOfSort = value;
                }
                get
                {
                    return OrderOfSort;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            listView1.Items.Add("Алла");
            listView1.Items.Add("София");
            listView1.Items[0].UseItemStyleForSubItems = false;
            listView1.Items[0].SubItems.Add("Пугачева", Color.Pink,
            Color.Yellow, Font);
            listView1.Items[1].UseItemStyleForSubItems = false;
            listView1.Items[1].SubItems.Add("Ротару", Color.Teal,
            Color.Violet, Font);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if ((int)Microsoft.Win32.Registry.GetValue(
            @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced","EnableBalloonTips", 1) == 0);
            // Не использовать стиль Balloon
            else
                MessageBox.Show("Not use Balloon style");
            
                this.toolTip1.IsBalloon = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.toolTip1.SetToolTip(this.button3, "Это кнопка\r\nСамая обычная кнопка");
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            if (contextMenuStrip1.SourceControl == label1)
            {
                cmenuOpen.Text = "Label";
            }
            else
                cmenuOpen.Text = "Button";
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }
    }
}
